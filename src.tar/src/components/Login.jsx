import React from 'react'
import './Login.css'
import { useHistory } from 'react-router-dom';


const Login = () => {

    const Submit = () => {
        console.log("On Submit called");
        // talk to server get JWT and store in Redux or session storage. 
        // On success
        // Use this JWT in the header of subsequent requests
        // close login screen
        // load home screen
        const history = useHistory();
        history.push('/home')
        //
        // On Fail 
        // inidiate fail on login components (Red border)

    };

    return (
        <div className="login">
            {/* <div className="curtains"></div> */}
            <div className="container">
                <div className = "logo">Logo</div>
                <div className="divider"><div className="line"></div></div>
                <div className="credentials">
                    <label>Username</label>
                    <input></input>
                    <label>password</label>
                    <input></input>
                    <input type="submit" onClick={Submit}/>
                </div>
            </div>
        </div>
    )
}

export default Login
