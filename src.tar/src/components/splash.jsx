import React from 'react'
import './splash.css'

const splash = () => {
    return (
        <div className="splash">
            
        </div>
    )
}

export default splash
