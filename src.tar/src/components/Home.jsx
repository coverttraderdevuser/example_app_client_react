import React from 'react'

const Home = () => {
    return (
        <div>
            This is the home page
        </div>
    )
}

export default Home
