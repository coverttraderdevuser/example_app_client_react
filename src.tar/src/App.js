import React from 'react';
import './App.css';
// import Splash from './components/splash'
import Login from './components/Login'
import { BrowserRouter as Router, Route} from 'react-router-dom'

function App() {
  return (
    <div className="App">
      
      <Router>
        <Route path={['/', '/login']} exact render = { () => (
          <>
          {<Login/>}
          </>
        )
          
        } 
        />
      
      </Router>
      {/* <Splash/> */}
      
    </div>
  );
}

export default App;
